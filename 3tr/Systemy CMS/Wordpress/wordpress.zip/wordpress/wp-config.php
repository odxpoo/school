<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the installation.
 * You don't have to use the web site, you can copy this file to "wp-config.php"
 * and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * Database settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://wordpress.org/documentation/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** Database settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'wordpress_database' );

/** Database username */
define( 'DB_USER', 'wordpress_cms' );

/** Database password */
define( 'DB_PASSWORD', '' );

/** Database hostname */
define( 'DB_HOST', 'localhost' );

/** Database charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The database collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication unique keys and salts.
 *
 * Change these to different unique phrases! You can generate these using
 * the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}.
 *
 * You can change these at any point in time to invalidate all existing cookies.
 * This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         'Su]<J6t)-G^d,9?euNB4IgedE&Zu sF=e_,:c9)JH:/pyXCE FhX_J{:608h=<H ' );
define( 'SECURE_AUTH_KEY',  'qvoXO|!BN9~*:&rG.9ub*21Z4~u]kCe.2C(_WYp>*Kj}wre8?Dg@q_#zsFP{66X,' );
define( 'LOGGED_IN_KEY',    'xGw?b|JE`HD N|xbpD*)*8@[ 5p!jX>d:bL3`],5%OYt5ku=Wi*b/sb;VF(Jd%?m' );
define( 'NONCE_KEY',        ',)Nyea#+,EQ>/s2H?SbjauSve1T;RA29:z68L/=EaS[$ny.J(QqCn.hQgM:LbO}.' );
define( 'AUTH_SALT',        'J {*GbH*lFx2#}8Oq)bcbAVpx,z`~0^$9EtQ6;qd.$BgXv4J[%-5T`e=CDu_gy|U' );
define( 'SECURE_AUTH_SALT', 'QZlx?#XHykG%%Zh[$zED(<{c%TewEX_b!xCbJ1Ea,;_Lvz 0bdJbk:?jUdFbKL-Y' );
define( 'LOGGED_IN_SALT',   ')0WbL{hr[,e,M[3D+3^2=o{z4hzZ3S81$h4 DC&m`nWwdhZCZ~^+y>j#;JQU~aGR' );
define( 'NONCE_SALT',       'w@w:]n6(N M4SXtq@dRwsp)VzO8cS^[sYcGJutC/`xvenh$iVsAAWpD6$`#BjvT5' );

/**#@-*/

/**
 * WordPress database table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/documentation/article/debugging-in-wordpress/
 */
define( 'WP_DEBUG', false );

/* Add any custom values between this line and the "stop editing" line. */



/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
